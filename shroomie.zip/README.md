>


## Installation

```bash
npm install
```

## Get started

```bash
npm start
```

